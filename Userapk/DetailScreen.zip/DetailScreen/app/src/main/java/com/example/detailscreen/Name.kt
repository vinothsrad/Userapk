package com.example.detailscreen

data class Name(
    val first: String,
    val last: String,
    val title: String
)