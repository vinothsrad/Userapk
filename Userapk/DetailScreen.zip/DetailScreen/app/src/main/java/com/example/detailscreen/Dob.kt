package com.example.detailscreen

data class Dob(
    val age: Int,
    val date: String
)