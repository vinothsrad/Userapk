package com.example.detailscreen

data class Street(
    val name: String,
    val number: Int
)