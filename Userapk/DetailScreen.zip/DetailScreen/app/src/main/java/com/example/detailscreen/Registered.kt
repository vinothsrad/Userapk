package com.example.detailscreen

data class Registered(
    val age: Int,
    val date: String
)