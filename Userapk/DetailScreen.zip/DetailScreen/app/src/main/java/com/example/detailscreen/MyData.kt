package com.example.detailscreen

data class MyData(
    val info: Info,
    val results: List<Result>
) {

}