package com.example.detailscreen

data class Timezone(
    val description: String,
    val offset: String
)