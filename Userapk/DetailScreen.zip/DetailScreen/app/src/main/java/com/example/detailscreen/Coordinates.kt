package com.example.detailscreen

data class Coordinates(
    val latitude: String,
    val longitude: String
)